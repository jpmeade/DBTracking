
  CREATE OR REPLACE TRIGGER "SDE"."LOCKS_AFTER_INSERT" 
AFTER INSERT
   ON table_locks
   FOR EACH ROW

DECLARE
  varOwner varchar(30);
  varNode varchar(256);
  varName varchar(160);
   
BEGIN

  Select owner Into varOwner
  From process_information
  Where sde_id = :new.sde_id;
  
  Select nodename Into varNode
  From process_information
  Where sde_id = :new.sde_id;
  
  Select table_name Into varName
  From table_registry
  Where registration_id = :new.registration_id;

   INSERT INTO sde_table_lock_log
   ( sde_id,
     username,
     computername,
     registration_id,
     table_name,
     lock_type )
   VALUES
   ( :new.sde_id,
     varOwner,
     varNode,
     :new.registration_id,
     varName,
     :new.lock_type );
     
END;

/
ALTER TRIGGER "SDE"."LOCKS_AFTER_INSERT" ENABLE;
